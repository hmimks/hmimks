/**
 * FAQ
 */
 "use strict";
//Class Definition
//Load Init 

var _closeDetailBerita = function() { 
    $('#gambarView').html(''),$('#modalDetailBerita h4').html(''),$('#modalDetailBerita p').html('');
    $('#modalDetailBerita').modal('hide');
	$('html, body').animate({
		scrollTop: $("#newsPage").offset().top
	}, 2000); 
} 


var _closeDetailDokumen = function() {  
    $('#modalDetailDokumen h2').html('');
    $('#modalDetailDokumen').modal('hide'); 
} 
var _showDokumenData = function(id_data) {
    $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
	
    $.ajax({
        url: BASE_URL+ "/dokumen/show/",
        type: "GET",
        dataType: "JSON",
        data: {
            'id': id_data
        }, success: function (data) { 
			$.unblockUI();
            if (data.status == true) {  
                if(data.dokumen_count==0){
                    $('#acc-dokumen').html('<h5 class="text-center pb-5">Tidak ada data</h5>');
                } else {
                    $('#acc-dokumen').html(data.dokumen_listall);
                }
                $('#modalDetailDokumen h2').html(id_data);
                $('#modalDetailDokumen').modal('show'); 
            } else {
                alert('Load data mengalami masalah, Periksa koneksi jaringan internet lalu coba kembali')
            }
        }, error: function (jqXHR, textStatus, errorThrown) {
			$.unblockUI();
            alert('Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.')
        }
    });
}

function downloadDokumen(urlDokumen) {  
	Swal.fire({
	  title: 'File/Dokumen', 
	  confirmButtonText: 'Tutup',
	  html:urlDokumen ? '<object data="'+urlDokumen+'" width="100%" height="400"></object><br><a href="'+urlDokumen+'" target="_blank">Klik untuk melihat file/dokumen</a>' : 'tidak ada data untuk bagian ini'
	})
} 

var _showDataBerita = function(id_data) {
    $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
	
    $.ajax({
        url: BASE_URL+ "/berita/detail/",
        type: "GET",
        dataType: "JSON",
        data: {
            'id': id_data
        }, success: function (data) { 
			$.unblockUI();
            if (data.status == true) {
				var gambar=data.detail.gambar; 
				if(gambar) { 
					$('#gambarView').html('<img src="'+gambar+'" width="100%">')	
				} else {
					$('#gambarView').html('')	
				}
                $('#modalDetailBerita h4').html(data.detail.judul),$('#modalDetailBerita p').html(data.detail.keterangan); 
                $('#modalDetailBerita').modal('show'); 
            } else {
                alert('Load data mengalami masalah, Periksa koneksi jaringan internet lalu coba kembali')
            }
        }, error: function (jqXHR, textStatus, errorThrown) {
			$.unblockUI();
            alert('Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.')
        }
    });
}

var _selengkapnyaPage = function() { 
    $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
	setTimeout($.unblockUI, 900);  
	$('html, body').animate({
        scrollTop: $("#tentangPage").offset().top
    }, 2000); 
    $('#tentang-data').hide(), $('#tentang-detail').show();
}
var _backPage = function() { 
    $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
	setTimeout($.unblockUI, 900);   
	$('html, body').animate({
        scrollTop: $("#tentangPage").offset().top
    }, 2000); 
    $('#tentang-detail').hide(), $('#tentang-data').show();
} 



$('#btn-subscriber').on('click', function (e) {
    e.preventDefault();
    $('#btn-subscriber').html('<i class="fa fa-spin fa-spinner"></i> Mohon Tunggu...').attr('disabled', true);
    const email_subscriber = $('#email_subscriber');     
	if (email_subscriber.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Email harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        email_subscriber.focus();
        $('#btn-subscriber').html('Subscribe').attr('disabled', false);
        return false;
    }     	
	
    Swal.fire({
        title: 'Halo!',  
        text: 'Apakah Anda yakin ingin memproses permintaan ini ?',  
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "Ya",
        cancelButtonText: "Batal"
    }).then(result => {
        if (result.value) {
            $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
            var formData = new FormData($('#form-subscriber')[0]), ajax_url= BASE_URL+ "/ajax_save_subscriber";
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON", 
                success: function (data) {
					$.unblockUI();
                    $('#btn-subscriber').html('Subscribe').attr('disabled', false);
                    
                    if (data.status==true){ 
						Swal.fire({
							icon: 'success', 
							text: 'Data berhasil disimpan. Terima kasih!',  
							confirmButtonText: 'Selesai!', 
						}).then((result) => {  
							$('#email_subscriber').val('');
						});  
                    }else{  
						if(data.pesan_code=='format_inputan') { 
							Swal.fire({ 
								title: 'Maaf!',
								text: data.pesan_error[0],
								allowOutsideClick: false, 
							}) 
						} else { 
							Swal.fire({ 
								title: 'Maaf!',
								text: 'Pastikan Anda melengkapi form dengan benar. Terima kasih!',
								allowOutsideClick: false, 
							})  
						} 
                    }
                }, error: function (jqXHR, textStatus, errorThrown) {
					$.unblockUI();
					$('#btn-subscriber').html('Subscribe').attr('disabled', false); 
					Swal.fire({ 
						title: 'Maaf!',
						text: 'Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.',
						allowOutsideClick: false, 
					})   
                }
            });
        } else {
            $('#btn-subscriber').html('Subscribe').attr('disabled', false);
        }
    });
});

$("#form-subscriber input").keyup(function(event) {
    if (event.keyCode == 13 || event.key === 'Enter') {
        $("#btn-subscriber").click();
    }
}); 

//LK3

$('#btn-lk3').on('click', function (e) {
    e.preventDefault();
    $('#btn-lk3').html('<i class="fa fa-spin fa-spinner"></i> Mohon Tunggu...').attr('disabled', true);
    const nama = $('#nama'),ttl = $('#ttl'),asal = $('#asal'),cabang = $('#cabang'),
    email = $('#email'),telp = $('#telp'),jabatan = $('#jabatan'),
    foto = $('#foto'),mengaji = $('#mengaji'),jurnal = $('#jurnal'),keterangan = $('#keterangan');     
	if (nama.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Nama harus diisi.',
			allowOutsideClick: false, 
		})     
        nama.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }        
	if (ttl.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Tempat dan Tanggal Lahir harus diisi.',
			allowOutsideClick: false, 
		})     
        ttl.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     	   
	if (asal.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Asal Badko​ harus diisi.',
			allowOutsideClick: false, 
		})     
        asal.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     	   	   
	if (cabang.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Asal cabang harus diisi.',
			allowOutsideClick: false, 
		})     
        cabang.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     	   	   
	if (email.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'email harus diisi.',
			allowOutsideClick: false, 
		})     
        email.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }  	   	   
	if (telp.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'telp harus diisi.',
			allowOutsideClick: false, 
		})     
        telp.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     		   
	if (jabatan.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Jabatan / Struktural Terakhir harus diisi.',
			allowOutsideClick: false, 
		})     
        jabatan.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     		   
	if (foto.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Pas Foto 3x4 harus diisi.',
			allowOutsideClick: false, 
		})     
        foto.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }  		   
	if (mengaji.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Link Mengaji di IG harus diisi.',
			allowOutsideClick: false, 
		})     
        mengaji.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }  		   
	if (jurnal.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Jurnal LK 3 harus diisi.',
			allowOutsideClick: false, 
		})     
        jurnal.focus();
        $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        return false;
    }     	
	
    Swal.fire({
        title: 'Halo!',  
        text: 'Apakah Anda yakin ingin memproses permintaan ini ?',  
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "Ya",
        cancelButtonText: "Batal"
    }).then(result => {
        if (result.value) {
            $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
            var formData = new FormData($('#form-lk3')[0]), ajax_url= BASE_URL+ "/ajax_save_lk3";
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON", 
                success: function (data) {
					$.unblockUI();
                    $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
                    
                    if (data.status==true){ 
						Swal.fire({
							icon: 'success', 
							text: 'Data Pendaftaran berhasil disimpan. Terima kasih!',  
							confirmButtonText: 'Selesai!', 
						}).then((result) => {   
							$('#nama').val(''),$('#ttl').val(''),$('#asal').val(''),$('#cabang').val(''),
                            $('#email').val(''),$('#telp').val(''),$('#jabatan').val(''),$('#foto').val(''),
                            $('#keterangan').val(''),$('#mengaji').val(''),$('#jurnal').val('');
                            window.location.href = BASE_URL+"/formulir-lk3";
						});  
                    }else{  
						if(data.pesan_code=='format_inputan') { 
							Swal.fire({ 
								title: 'Maaf!',
								text: data.pesan_error[0],
								allowOutsideClick: false, 
							}) 
						} else { 
							Swal.fire({ 
								title: 'Maaf!',
								text: 'Pastikan Anda melengkapi form dengan benar. Terima kasih!',
								allowOutsideClick: false, 
							})  
						} 
                    }
                }, error: function (jqXHR, textStatus, errorThrown) {
					$.unblockUI();
					$('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false); 
					Swal.fire({ 
						title: 'Maaf!',
						text: 'Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.',
						allowOutsideClick: false, 
					})   
                }
            });
        } else {
            $('#btn-lk3').html('Kirim Pendaftaran LK3').attr('disabled', false);
        }
    });
});

$("#form-lk3 input").keyup(function(event) {
    if (event.keyCode == 13 || event.key === 'Enter') {
        $("#btn-lk3").click();
    }
}); 
//LK3

//CENTRUM

$('#btn-centrum').on('click', function (e) {
    e.preventDefault();
    $('#btn-centrum').html('<i class="fa fa-spin fa-spinner"></i> Mohon Tunggu...').attr('disabled', true);
    const nama = $('#nama'),email = $('#email'),telp = $('#telp'),jabatan = $('#jabatan'),dokumen = $('#dokumen');     
	if (nama.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Nama harus diisi.',
			allowOutsideClick: false, 
		})     
        nama.focus();
        $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        return false;
    }             	   	   
	if (email.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'email harus diisi.',
			allowOutsideClick: false, 
		})     
        email.focus();
        $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        return false;
    }  	   	   
	if (telp.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'telp harus diisi.',
			allowOutsideClick: false, 
		})     
        telp.focus();
        $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        return false;
    }   	   	   
	if (jabatan.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'jabatan/bidang harus diisi.',
			allowOutsideClick: false, 
		})     
        jabatan.focus();
        $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        return false;
    }             	   	   
	if (dokumen.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'dokumen harus diisi.',
			allowOutsideClick: false, 
		})     
        dokumen.focus();
        $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        return false;
    }  	  	
	
    Swal.fire({
        title: 'Halo!',  
        text: 'Apakah Anda yakin ingin memproses permintaan ini ?',  
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "Ya",
        cancelButtonText: "Batal"
    }).then(result => {
        if (result.value) {
            $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
            var formData = new FormData($('#form-centrum')[0]), ajax_url= BASE_URL+ "/ajax_save_datacentrum";
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON", 
                success: function (data) {
					$.unblockUI();
                    $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
                    
                    if (data.status==true){ 
						Swal.fire({
							icon: 'success', 
							text: 'Datacentrum berhasil disimpan. Terima kasih!',  
							confirmButtonText: 'Selesai!', 
						}).then((result) => {   
							$('#nama').val(''),$('#ttl').val(''),$('#asal').val(''),$('#cabang').val(''),
                            $('#email').val(''),$('#telp').val(''),$('#jabatan').val(''),$('#foto').val(''),
                            $('#keterangan').val(''),$('#mengaji').val(''),$('#jurnal').val('');
                            window.location.href = BASE_URL+"/formulir-datacentrum";
						});  
                    }else{  
						if(data.pesan_code=='format_inputan') { 
							Swal.fire({ 
								title: 'Maaf!',
								text: data.pesan_error[0],
								allowOutsideClick: false, 
							}) 
						} else { 
							Swal.fire({ 
								title: 'Maaf!',
								text: 'Pastikan Anda melengkapi form dengan benar. Terima kasih!',
								allowOutsideClick: false, 
							})  
						} 
                    }
                }, error: function (jqXHR, textStatus, errorThrown) {
					$.unblockUI();
					$('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false); 
					Swal.fire({ 
						title: 'Maaf!',
						text: 'Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.',
						allowOutsideClick: false, 
					})   
                }
            });
        } else {
            $('#btn-centrum').html('Kirim Datacentrum').attr('disabled', false);
        }
    });
});

$("#form-centrum input").keyup(function(event) {
    if (event.keyCode == 13 || event.key === 'Enter') {
        $("#btn-centrum").click();
    }
}); 
//CENTRUM

//PENGADUAN
$('#btn-pengaduan').on('click', function (e) {
    e.preventDefault();
    $('#btn-pengaduan').html('<i class="fa fa-spin fa-spinner"></i> Mohon Tunggu...').attr('disabled', true);
    const nama = $('#nama'),email = $('#email'),cabang = $('#cabang'),telp = $('#telp'),pengaduan = $('#pengaduan');     
	if (nama.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Nama harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        nama.focus();
        $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        return false;
    }     	   
	if (email.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'Email harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        email.focus();
        $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        return false;
    }       	   
	if (cabang.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'cabang harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        cabang.focus();
        $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        return false;
    }        	   
	if (telp.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'telp harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        telp.focus();
        $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        return false;
    }        	   
	if (pengaduan.val() == '') {
		Swal.fire({ 
			title: 'Maaf!',
			text: 'isi pengaduan harus diisi terlebih dahulu. terlihat saat ini masih kosong...',
			allowOutsideClick: false, 
		})     
        pengaduan.focus();
        $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        return false;
    }     	
	
    Swal.fire({
        title: 'Halo!',  
        text: 'Apakah Anda yakin ingin memproses permintaan ini ?',  
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "Ya",
        cancelButtonText: "Batal"
    }).then(result => {
        if (result.value) {
            $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } }); 
            var formData = new FormData($('#form-pengaduan')[0]), ajax_url= BASE_URL+ "/ajax_save_pengaduan";
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON", 
                success: function (data) {
					$.unblockUI();
                    $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
                    
                    if (data.status==true){ 
						Swal.fire({
							icon: 'success', 
							text: 'Data Pengaduan berhasil dikirim. Terima kasih!',  
							confirmButtonText: 'Selesai!', 
						}).then((result) => {  
							$('#nama').val('');
							$('#email').val('');
							$('#cabang').val('');
							$('#telp').val('');
							$('#pengaduan').val(''); 
						});  
                    }else{  
						if(data.pesan_code=='format_inputan') { 
							Swal.fire({ 
								title: 'Maaf!',
								text: data.pesan_error[0],
								allowOutsideClick: false, 
							}) 
						} else { 
							Swal.fire({ 
								title: 'Maaf!',
								text: 'Pastikan Anda melengkapi form dengan benar. Terima kasih!',
								allowOutsideClick: false, 
							})  
						} 
                    }
                }, error: function (jqXHR, textStatus, errorThrown) {
					$.unblockUI();
					$('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false); 
					Swal.fire({ 
						title: 'Maaf!',
						text: 'Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.',
						allowOutsideClick: false, 
					})   
                }
            });
        } else {
            $('#btn-pengaduan').html('Kirim Pengaduan').attr('disabled', false);
        }
    });
});

$("#form-pengaduan input").keyup(function(event) {
    if (event.keyCode == 13 || event.key === 'Enter') {
        $("#btn-pengaduan").click();
    }
}); 