/**
 * Login
 */
 "use strict";
$('#btn-save').on('click', function (e) {
    e.preventDefault();
    $('#btn-save').html('<i class="fa fa-spin fa-spinner"></i> Mohon Tunggu...').attr('disabled', true);
    const email = $('#email'),password = $('#password');
	if (email.val() == '') {
		Swal.fire({
			title: 'Maaf!',
			text: 'Email tidak boleh kosong...',
			allowOutsideClick: false,
		})
        email.focus();
        $('#btn-save').html('Login').attr('disabled', false);
        return false;
    }
	if (password.val() == '') {
		Swal.fire({
			title: 'Maaf!',
			text: 'Password tidak boleh kosong...',
			allowOutsideClick: false,
		})
        password.focus();
        $('#btn-save').html('Login').attr('disabled', false);
        return false;
    }

    Swal.fire({
        title: 'Halo!',
        text: 'Yakin ingin login dengan akun ini ?',
        showCancelButton: true,
        allowOutsideClick: false,
        confirmButtonText: "Ya",
        cancelButtonText: "Batal"
    }).then(result => {
        if (result.value) {
            $.blockUI({ message: 'Sedang memproses...', css: { border: 'none', padding: '12px', backgroundColor: '#fff', '-webkit-border-radius': '10px', '-moz-border-radius': '10px', opacity: .9, color: '#222' } });
            var formData = new FormData($('#form-data')[0]), ajax_url= BASE_URL+ "/ajax_login";
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                dataType: "JSON",
                success: function (data) {
					$.unblockUI();
                    $('#btn-save').html('Login').attr('disabled', false);

                    if (data.status==true){
						Swal.fire({
							icon: 'success',
							text: 'Anda berhasil Login. Sistem akan mengarahkan Anda ke halaman Dashboard Anda. Terima kasih!',
							confirmButtonText: 'Lanjutkan!',
						}).then((result) => {
                            window.location.href = BASE_URL+"/home";
						});
                    }else{
						if(data.pesan_code=='format_inputan') {
							Swal.fire({
								title: 'Maaf!',
								text: data.pesan_error[0],
								allowOutsideClick: false,
							})
						} else {
							Swal.fire({
								title: 'Maaf!',
								text: 'Akun yang dimasukkan tidak terdeteksi oleh sistem ini. Mohon periksa Akun yang Anda gunakan. Terima kasih!',
								allowOutsideClick: false,
							})
						}
                    }
                }, error: function (jqXHR, textStatus, errorThrown) {
					$.unblockUI();
					$('#btn-save').html('Login').attr('disabled', false);
					console.error("Error details:", textStatus, errorThrown); // Menambahkan log kesalahan
					Swal.fire({
						title: 'Maaf!',
						text: 'Terjadi kesalahan yang tidak diketahui, Periksa koneksi jaringan internet lalu coba kembali. Mohon hubungi pengembang jika masih mengalami masalah yang sama.',
						allowOutsideClick: false,
					})
                }
            });
        } else {
            $('#btn-save').html('Login').attr('disabled', false);
        }
    });
});

$("#form-data input").keyup(function(event) {
    if (event.keyCode == 13 || event.key === 'Enter') {
        $("#btn-save").click();
    }
});